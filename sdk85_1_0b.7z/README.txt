This archive contains the source code for the SDK80 monitor.  It was OCR'ed and edited by Walter Kaiserseder
from Intel Order Number 9800203B. That document is at this link:

http://www.nj7p.info/Manuals.PDFs/Intel/9800203B.pdf

The final file is sdk80.asm.  This file is complete.

Bill Beech
5 June 2020